/**
 * Module 10 – Structured Logger
 * Pino-based, JSON output in production.
 */

import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  transport:
    process.env.NODE_ENV !== 'production'
      ? { target: 'pino-pretty', options: { colorize: true } }
      : undefined,
  base: { service: 'module-10-orchestrator', version: process.env.npm_package_version },
  timestamp: pino.stdTimeFunctions.isoTime,
});
