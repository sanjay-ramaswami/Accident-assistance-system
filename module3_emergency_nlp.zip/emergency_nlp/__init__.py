"""Module 3 — Emergency NLP / LLM (Understanding & Classification)"""
__version__ = "1.0.0"
